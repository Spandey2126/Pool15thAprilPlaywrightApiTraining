function arraySumUsingReduce(array){
let sum = array.reduce((acc,value)=>{ return acc+value},0);
console.log(sum);
return sum;
}
arraySumUsingReduce([1,2,3,4])
