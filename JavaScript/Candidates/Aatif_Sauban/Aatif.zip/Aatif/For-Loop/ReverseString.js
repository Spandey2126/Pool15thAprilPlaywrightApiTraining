function reverseString(str) {
    let reversed = "";
    for (let i = str.length - 1; i >= 0; i--) {
        reversed += str[i]; // add characters from end to start
    }
    console.log(reversed);
    return reversed;
}

// Example usage:
reverseString("Hello World");
