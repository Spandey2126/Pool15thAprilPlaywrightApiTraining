function sumOfFirstNnumbers(n) {
    let total = 0;
    for (let i = 1; i <= n; i++) {
        total += i;
    }
    console.log(total);
}
sumOfFirstNnumbers(5);