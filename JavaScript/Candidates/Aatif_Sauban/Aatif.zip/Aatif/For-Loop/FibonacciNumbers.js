function fibonacciArray(n) {
    let arr = [];
    let a = 0, b = 1;
    arr.push(a);
    if (n > 1) arr.push(b);

    for (let i = 2; i < n; i++) {
        let next = a + b;
        arr.push(next);
        a = b;
        b = next;
    }
    return arr;
}

console.log(fibonacciArray(10));

