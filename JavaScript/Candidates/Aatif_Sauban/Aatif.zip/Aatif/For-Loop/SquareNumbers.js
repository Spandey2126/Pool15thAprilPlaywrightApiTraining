function printSquares() {
    for (let i = 1; i <= 10; i++) {
        console.log(i * i); // square of i
    }
}

printSquares();
