function FactorialCalculator(n) {
    let factorial = 1;
    for (let i = 1; i <= n; i++) {
        factorial *= i;

    }
    return factorial;
}

console.log(FactorialCalculator(4))
