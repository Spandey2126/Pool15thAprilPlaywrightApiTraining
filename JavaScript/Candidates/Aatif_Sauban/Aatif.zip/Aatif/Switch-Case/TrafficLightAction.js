function trafficLightAction(traficLightColour) {
    let colour = traficLightColour.toLowerCase();
    switch (colour) {
        case "red":
            console.log("Stop");
            break;
        case "yellow":
            console.log("Wait");
            break;
        case "green":
            console.log("Go");
            break;
        default:
            console.log("Invalid Colour")
    }
}
trafficLightAction("GREEN");
trafficLightAction("blue");
trafficLightAction("Red");
trafficLightAction("Yellow");