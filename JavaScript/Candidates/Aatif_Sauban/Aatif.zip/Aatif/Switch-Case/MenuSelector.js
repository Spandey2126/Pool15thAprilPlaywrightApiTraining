function menuSelector(MenuNumber) {
    switch (MenuNumber) {
        case 1:
            console.log("Pizza");
            break;
        case 2:
            console.log("Burger");
            break;
        case 3:
            console.log("Salad");
            break;
        default:
            console.log("Invalid Items");

    }
}
menuSelector(1);
menuSelector(2);
menuSelector(3);
menuSelector(4);