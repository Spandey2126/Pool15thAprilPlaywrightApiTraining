function vowelorConsonant(character) {
    let ch = character.toLowerCase();
    switch (ch) {
        case "a":
            console.log("vowel");
            break;
        case "e":
            console.log("vowel");
            break;
        case "i":
            console.log("vowel");
            break;
        case "o":
            console.log("vowel");
            break;
        case "u":
            console.log("vowel");
            break;
        default:
            console.log("Consonant");

    }
}
vowelorConsonant("a");
vowelorConsonant("b");