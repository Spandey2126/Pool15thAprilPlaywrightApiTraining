function gradeLetter(score) {
    switch (Math.floor(score / 10)) {
        case 10:
            console.log("A");
            break;

        case 9:
            console.log("A");
            break;
        case 8:
            console.log("B");
            break;
        case 7:
            console.log("C");
            break;
        case 6:
            console.log("D");
            break;
        case 5:
            console.log("E");
            break;
        default:
            console.log("F");
    }
}
gradeLetter(91);
gradeLetter(85);
gradeLetter(49);
gradeLetter(100);
