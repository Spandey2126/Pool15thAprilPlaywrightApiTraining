function simpleCalculator(num1, num2, operator) {
    switch (operator) {
        case '+':
            console.log(num1 + num2);
            break;
        case '-':
            console.log(num1 - num2);
            break;
        case '/':
            console.log(num1 / num2);
            break;
        case '*':
            console.log(num1 * num2);
            break;
        default:
            console.log("Invalid Operator");
    }
}
simpleCalculator(2,5,"+");
simpleCalculator(10,5,"-");
simpleCalculator(10,5,"/");
simpleCalculator(2,5,"*");