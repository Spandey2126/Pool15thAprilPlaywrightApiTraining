function animalSound(animalsound) {
    let sound = animalsound.toLowerCase();
    switch (sound) {
        case "dog":
            console.log("Woof");
            break;
        case "cat":
            console.log("Meow");
            break;
        case "cow":
            console.log("Moo");
            break;
        default:
            console.log("unknown animals.");
    }
}
animalSound("Dog");
animalSound("Cat");
animalSound("COW");
animalSound("Elephant");
