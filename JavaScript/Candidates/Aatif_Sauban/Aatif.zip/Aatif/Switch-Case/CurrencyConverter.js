function currencyConverter(currencyCode) {
    let code = currencyCode.toUpperCase();
    switch (code) {
        case "USD":
            console.log("United States Dollar");
            break;
        case "EUR":
            console.log("Euro");
            break;
        case "GBP":
            console.log("Great Britain Pound");
            break;
        default:
            console.log("Invalid currency code");

    }
}
currencyConverter("USD");
currencyConverter("gbp");
currencyConverter("eur");
currencyConverter("inr");