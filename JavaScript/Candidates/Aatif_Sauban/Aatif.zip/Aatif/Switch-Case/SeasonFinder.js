function seasonFinder(Month) {
    switch (Month) {
        case 1:
        case 2:
        case 3:
            console.log("Winter");
            break;
        case 4:
        case 5:
        case 6:
            console.log("Spring");
            break;
        case 7:
        case 8:
        case 9:
            console.log("Summer");
            break;
        case 10:
        case 11:
        case 12:
            console.log("Fall");
            break;
        default:
            console.log("Invalid Month")
    }
}
seasonFinder(1);
seasonFinder(2);
seasonFinder(12);
seasonFinder(11);
seasonFinder(10);
seasonFinder(5);
seasonFinder(9);
seasonFinder(20);
