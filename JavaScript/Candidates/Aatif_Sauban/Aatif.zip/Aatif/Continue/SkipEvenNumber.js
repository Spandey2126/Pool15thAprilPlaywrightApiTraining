function skipEvenNumbers() {
    for (let i = 1; i <= 10; i++) {
        if (i % 2 == 0) {
            continue;
        }
        else {
            console.log(i)
        }
    }
}
skipEvenNumbers();