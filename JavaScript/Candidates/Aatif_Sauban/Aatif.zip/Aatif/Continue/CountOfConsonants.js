function countOfConsonants(input) {
    let count = 0;
    let vowels = "aeiouAEIOU"
    for (let i = 0; i < input.length; i++) {
        if (vowels.includes(input[i])) {
            continue;
        }
        else{
            count++;
        }
    }
    console.log(count);
}
countOfConsonants("Aatif");
countOfConsonants("Zensar");
