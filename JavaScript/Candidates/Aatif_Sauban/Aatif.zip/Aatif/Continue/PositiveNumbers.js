function positiveNumbers(num) {
    
    for (let i = 0; i < num.length; i++) {
        if (num[i] < 0) {
            continue;
        }
        else {
        
           console.log(num[i]);
        }
    }
  
}
positiveNumbers([1,-2,3,-4,-5,-6,6,7,-8]);