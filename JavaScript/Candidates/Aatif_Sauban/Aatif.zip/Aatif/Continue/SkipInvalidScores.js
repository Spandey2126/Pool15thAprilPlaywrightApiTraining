function skipInvalidScores(scores) {
    let sum = 0;
    let count = 0;
    let average;
    for (let i = 0; i < scores.length; i++) {
        if (scores[i] < 0 || scores[i] > 100) {
            continue;
        }
        else {
            count++;
            sum += scores[i];
        }
    }
    average = sum / count;
    console.log(average)
}

skipInvalidScores([99, 30, 50, -20, 120, 150])