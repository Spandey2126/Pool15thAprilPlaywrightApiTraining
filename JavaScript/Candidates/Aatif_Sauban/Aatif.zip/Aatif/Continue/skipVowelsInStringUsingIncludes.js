function skipVowelsInString(input) {
    let vowels = "aeiouAEIOU"
    for (let i = 0; i < input.length; i++) {
        if (vowels.includes(input[i])) {
            continue;
        }
        else{
            console.log(input[i]);
        }
    }
}
skipVowelsInString("Sauban");