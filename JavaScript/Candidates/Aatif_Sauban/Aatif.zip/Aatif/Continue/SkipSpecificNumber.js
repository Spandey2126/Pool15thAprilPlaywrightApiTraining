function skipSpecificNumber(n) {
    for (let i = 1; i <= 15; i++) {
        if (i == n) {
            continue;
        }
        else{
            console.log(i);
        }
    }
}
skipSpecificNumber(7);
