function skipEmptyStrings(arr) {
    for (word of arr) {
        if (word.length === 0) {
            continue;
        }
        else{
            console.log(word);
        }
    }

}
skipEmptyStrings(["Aatif","", "Sauban","", ""])
