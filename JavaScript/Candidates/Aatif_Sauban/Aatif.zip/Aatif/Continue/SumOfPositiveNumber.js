function sumOfpositiveNumbers(num) {
    let sum=0;
    for (let i = 0; i < num.length; i++) {
        if (num[i] < 0) {
            continue;
        }
        else {
           sum += num[i]; 
          
        }
    }
   console.log(sum);
}
sumOfpositiveNumbers([1,-2,3,-4,-5,-6,6,7,-8]);