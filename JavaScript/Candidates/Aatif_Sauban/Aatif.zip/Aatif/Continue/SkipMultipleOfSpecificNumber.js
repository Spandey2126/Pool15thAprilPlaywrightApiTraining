function skipMultipleOfSpecificNumber(n) {
    for (let i = 1; i <= 50; i++) {
        if (i % n == 0) {
            continue;
        }
        else{
            console.log(i);
        }
    }
}
skipMultipleOfSpecificNumber(5);