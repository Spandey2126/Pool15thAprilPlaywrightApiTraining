function skipMultipleOfN(n) {
    for (let i = 1; i <= 20; i++) {
        if (i % n === 0) {
            continue; // skip multiples of n
        }
        console.log(i);
    }
}

// Example usage:
skipMultipleOfN(3);  // skips 3, 6, 9, 12, 15, 18
skipMultipleOfN(5);  // skips 5, 10, 15, 20
