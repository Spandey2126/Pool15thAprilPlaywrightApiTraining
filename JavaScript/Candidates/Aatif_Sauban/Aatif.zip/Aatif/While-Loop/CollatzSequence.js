function collatzSequence(num) {
    console.log(num); // print the starting number

    while (num !== 1) {
        if (num % 2 === 0) {
            num = num / 2;        // if even, divide by 2
        } else {
            num = num * 3 + 1;    // if odd, multiply by 3 and add 1
        }
        console.log(num); // print each step
    }
}

// Example usage:
collatzSequence(6);
