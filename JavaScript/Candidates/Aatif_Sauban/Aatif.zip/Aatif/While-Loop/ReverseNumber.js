function reverseNumber(num) {
    let reversed = 0;

    while (num > 0) {
        let digit = num % 10;           // extract last digit
        reversed = reversed * 10 + digit; // build reversed number
        num = Math.floor(num / 10);     // remove last digit
    }

    console.log("Reversed number:", reversed);
    return reversed;
}

// Example usage:
reverseNumber(123);   // prints 321
reverseNumber(9876);  // prints 6789
