function sumOfArray(array) {
    let sum = 0;
    let i = 0;

    while (i < array.length) {
        sum += array[i]; // add current element
        i++;             // move to next index
    }

    console.log("Sum of array elements:", sum);
    return sum;
}

// Example usage:
sumOfArray([10, 20, 30]); // prints 60
