function countDigits(num) {
    let count = 0;

    while (num > 0) {
        num = Math.floor(num / 10); // remove last digit
        count++;                    // increase digit count
    }

    console.log("Number of digits:", count);
    return count;
}

// Example usage:
countDigits(12345); // prints 5
