function sumUntilLimit(limit) {
    let sum = 0;
    let i = 1;

    while (sum <= limit) {
        sum += i;   // add current number
        i++;        // move to next number
    }

    console.log("Final sum:", sum);
}

// Example usage:
sumUntilLimit(50);
