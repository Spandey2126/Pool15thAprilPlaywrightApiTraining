function printOddNumbers() {
    let i = 1; // start from 1

    while (i <= 20) {
        if (i % 2 !== 0) { // check if odd
            console.log(i);
        }
        i++; // increment by 1
    }
}

printOddNumbers();
