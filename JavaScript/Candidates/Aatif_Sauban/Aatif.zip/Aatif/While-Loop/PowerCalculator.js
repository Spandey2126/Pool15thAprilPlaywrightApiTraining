function powerCalculator(base, exponent) {
    let result = 1;
    let count = 0;

    while (count < Math.abs(exponent)) {
        result *= base;
        count++;
    }

    if (exponent < 0) {
        result = 1 / result; // invert for negative exponent
    }

    console.log(`${base}^${exponent} = ${result}`);
    return result;
}

powerCalculator(2, -3); // prints 0.125
