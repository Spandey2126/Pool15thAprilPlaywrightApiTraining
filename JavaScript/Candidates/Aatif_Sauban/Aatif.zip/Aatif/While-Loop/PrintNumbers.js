function printNumbers() {
    let i = 1; // counter starts at 1
    while (i <= 10) {
        console.log(i); // print current number
        i++;            // increment counter
    }
}

printNumbers();
