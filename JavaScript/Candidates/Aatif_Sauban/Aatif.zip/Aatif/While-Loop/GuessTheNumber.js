const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const secret = 11; // number to guess

function askGuess() {
    rl.question("Guess the number: ", (answer) => {
        let guess = parseInt(answer, 10);

        if (guess === secret) {
            console.log("Correct! The number was " + secret);
            rl.close(); // stop program
        } else {
            console.log("Wrong guess, try again!");
            askGuess(); // keep asking until correct
        }
    });
}

askGuess();
