function findSmallestDivisor(num) {
    if (num <= 1) {
        console.log("Number must be greater than 1");
        return;
    }

    for (let i = 2; i <= num; i++) {
        if (num % i === 0) {
            console.log("Smallest divisor of", num, "is:", i);
            break; // stop once the first divisor is found
        }
    }
}

// Example usage:
findSmallestDivisor(91);   // Smallest divisor of 91 is: 7
findSmallestDivisor(100);  // Smallest divisor of 100 is: 2