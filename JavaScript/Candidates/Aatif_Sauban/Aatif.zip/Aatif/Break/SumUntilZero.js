const prompt = require("prompt-sync")(); // install with: npm install prompt-sync

function sumUntilZero() {
    let sum = 0;

    while (true) {
        let input = prompt("Enter a number (0 to stop): ");
        let num = Number(input);

        if (num === 0) {
            break; // stop when input is 0
        }

        sum += num;
    }

    console.log("Final sum:", sum);
}

sumUntilZero();
