function searchCharacter(str) {
    let found = false;

    for (let i = 0; i < str.length; i++) {
        if (str[i] === "a") {
            console.log(`First 'a' found at position: ${i}`);
            found = true;
            break; // stop after finding the first 'a'
        }
    }

    if (!found) {
        console.log("Not found");
    }
}

// Example usage:
searchCharacter("hello world");   // Not found
searchCharacter("javascript");    // First 'a' found at position: 1
