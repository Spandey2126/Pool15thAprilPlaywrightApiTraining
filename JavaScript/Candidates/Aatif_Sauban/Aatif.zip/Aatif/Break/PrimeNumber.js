function isPrime(num) {
    if (num <= 1) {
        console.log(num + " is not prime");
        return false;
    }

    let isPrimeFlag = true;

    for (let i = 2; i <= Math.sqrt(num); i++) {
        if (num % i === 0) {
            console.log(num + " is not prime (divisible by " + i + ")");
            isPrimeFlag = false;
            break; // stop once a divisor is found
        }
    }

    if (isPrimeFlag) {
        console.log(num + " is prime");
    }

    return isPrimeFlag;
}

// Example usage:
isPrime(29);  // prime
isPrime(30);  // not prime
