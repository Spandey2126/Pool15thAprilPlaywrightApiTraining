function stopAtGivenNumber(n) {
    for (let i = 1; i <= 10; i++) {
        if (i === n) {
            break; // exit the loop when i equals n
        }
        console.log(i);
    }
}

// Call the function correctly:
stopAtGivenNumber(5);
