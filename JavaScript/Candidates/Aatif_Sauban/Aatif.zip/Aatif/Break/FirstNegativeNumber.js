function findFirstNegative(arr) {
    let found = false;

    for (let i = 0; i < arr.length; i++) {
        if (arr[i] < 0) {   // check if negative
            console.log("First negative number:", arr[i]);
            found = true;
            break;          // stop after finding the first negative
        }
    }

    if (!found) {
        console.log("No negative number found");
    }
}

// Example usage:
findFirstNegative([5, 12, -3, 7, -8]);   // First negative number: -3
findFirstNegative([10, 20, 30]);         // No negative number found
