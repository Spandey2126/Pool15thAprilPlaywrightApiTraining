function stopAtVowel(str) {
    const vowels = "aeiouAEIOU";

    for (let i = 0; i < str.length; i++) {
        if (vowels.includes(str[i])) {
            console.log("Vowel found:", str[i], "at position", i);
            break; // stop when a vowel is detected
        }
        console.log(str[i]); // print characters until vowel
    }
}

// Example usage:
stopAtVowel("strong");   // prints s, t, r then stops at 'o'
stopAtVowel("sky");      // prints s, k, y (no vowel found)
