function limitSum() {
    let sum = 0;
    let i = 1;

    while (i <= 100) {
        sum += i; // add current number

        if (sum > 50) {
            console.log("Sum exceeded 50!");
            console.log("Final sum:", sum);
            console.log("Last number added:", i);
            break; // stop once sum exceeds 50
        }

        i++; // move to next number
    }
}

limitSum();
