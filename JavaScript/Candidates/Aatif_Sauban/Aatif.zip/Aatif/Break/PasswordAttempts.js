// install with: npm install prompt-sync

const prompt = require("prompt-sync")(); 

function passwordAttempts() {
    const correctPassword = "secret123";
    let attempts = 0;

    while (attempts < 3) {
        let input = prompt("Enter password: ");
        attempts++;

        if (input === correctPassword) {
            console.log("Access granted.");
            break; // exit loop immediately on success
        } else {
            console.log("Wrong password. Attempts left:", 3 - attempts);
        }

        if (attempts === 3) {
            console.log("Access denied. Too many attempts.");
        }
    }
}

passwordAttempts();
