function findFirstEven(arr) {
    for (let i = 0; i < arr.length; i++) {
        if (arr[i] % 2 === 0) {   // check if even
            console.log("First even number:", arr[i]);
            break;                // stop after finding the first even
        }
    }
}

// Example usage:
findFirstEven([3, 7, 11, 8, 15, 20]);
