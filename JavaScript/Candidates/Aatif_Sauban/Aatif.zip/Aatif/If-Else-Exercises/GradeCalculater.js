let gradeCalculator = num => {

    if (num >= 90 && num <= 100) {
        console.log(`Grade : A`);
    }
    else if (num >= 80 && num <= 89) {
        console.log(`Grade : B`);
    }
    else if (num >= 70 && num <= 79) {
       console.log(`Grade : C`);
    }
    else if (num >= 60 && num <= 69) {
       console.log(`Grade : D`);
    }
    else if (num < 60) {
        console.log(`Grade : F`);
    }
    else{
        console.log(`Please enter the range between 0 to 100`);
    }
}
gradeCalculator(20)