function positive_Negative(num)
{
if (num == 0 )
{
    console.log(`The given num = ${num} is zero`);
}
else if (num>0)
{
    console.log(`The given num = ${num} is positive`);
}
else
{
    console.log(`The given num = ${num} is negative`);
}
}
 positive_Negative(-2)
