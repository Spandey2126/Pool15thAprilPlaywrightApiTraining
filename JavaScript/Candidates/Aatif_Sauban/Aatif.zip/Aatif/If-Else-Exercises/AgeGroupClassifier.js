function ageGroupClassifier(num)
{
if (num>=0 && num<=12)
{
console.log(`The given age = ${num} person is Child`);
}
else if(num>=13 && num <=19)
{
console.log(`The given age = ${num} person is Teen`);
}
else if (num>=20)
{
console.log(`The given age = ${num} person is Adult`);
}
else
{
    console.log(`The given age = ${num} is not withing a expected range`);
}
}

 ageGroupClassifier(12)
