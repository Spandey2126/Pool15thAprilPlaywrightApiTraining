let tempratureChecker = temp => {
    if (temp > 30) {
        return "Hot"
    }
    else if (temp >= 20 && temp <= 30) {
        return "Confortable"
    }
    else if (temp < 20) {
        return "Too Cold"
    }
}
console.log (tempratureChecker(21));