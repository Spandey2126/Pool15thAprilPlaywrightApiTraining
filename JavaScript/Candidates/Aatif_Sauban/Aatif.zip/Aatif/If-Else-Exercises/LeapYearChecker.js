let leapyear = function(num){
if ((num%4===0 && num%100!==0 ) || (num%400===0))
{
console.log("Leap Year")
}
else{
    console.log("Not a leap year")
}
}
leapyear(2024);