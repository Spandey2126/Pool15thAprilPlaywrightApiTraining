let largerNumber = (num1, num2) => {
    if (num1 > num2) {
        return num1;
    }
    else if (num1 < num2) {
        return num2;
    }
    else  {
        return "both the number are equal"
    }
}
console.log(largerNumber(-15, -16));