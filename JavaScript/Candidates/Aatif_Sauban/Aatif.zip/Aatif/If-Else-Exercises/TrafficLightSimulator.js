function trafficLightSimulator(colour) {
    colour = colour.toLowerCase();
    if (colour === "red")
        return "Stop";
    else if (colour === "yellow")
        return "Wait";
    else if (colour === "green")
        return "Go";
    else
        return "Invalid Colour"
}
console.log(trafficLightSimulator("Yellow"));
console.log(trafficLightSimulator("green"));
console.log(trafficLightSimulator("RED"));
console.log(trafficLightSimulator("blue"));