function loginValidation(username, password) {
    if (username==="admin" && password === 12345) {
        return "Access Granted"

    }
    else {
        return "Access Denied"
    }
}
console.log(loginValidation("admin1", 12345));
console.log(loginValidation("admin", 12345));