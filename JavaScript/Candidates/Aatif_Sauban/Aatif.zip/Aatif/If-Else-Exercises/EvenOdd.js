
function evenOdd(num)
{
if (num%2==0)
{
    console.log(`The given number = ${num} is even number `);
}
else
{
console.log(`The given number = ${num} is Odd number `);
}
}

evenOdd(5);